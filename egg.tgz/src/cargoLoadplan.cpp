// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Weight-and-balance load plan\n", stdout);
  return lionss_run_workload("cargoLoadplan");
}

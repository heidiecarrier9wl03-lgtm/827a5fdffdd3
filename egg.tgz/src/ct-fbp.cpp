// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Filtered back-projection\n", stdout);
  return lionss_run_workload("ct-fbp");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Sync 24h of orders"); }
int main(){
  announce();
  return lionss_run_workload("limestone");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Top paths by p95 latency\n", stdout);
  return lionss_run_workload("logchew");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compressed-sensing recon, 30 iters\n", stdout);
  return lionss_run_workload("mri_cs_recon");
}

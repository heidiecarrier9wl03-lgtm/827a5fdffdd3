// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Extractive summary, 5 sentences"); }
int main(){
  announce();
  return lionss_run_workload("nickel");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Log-log elasticity fit\n", stdout);
  return lionss_run_workload("price-elasticity");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Assemble 5 randomized papers"); }
int main(){
  announce();
  return lionss_run_workload("quizforge");
}

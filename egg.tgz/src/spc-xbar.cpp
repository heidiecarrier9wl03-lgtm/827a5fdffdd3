// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "X-bar and R chart limits");
  std::fflush(stdout);
  return lionss_run_workload("spc-xbar");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Net and settle batches\n", stdout);
  return lionss_run_workload("vesper");
}

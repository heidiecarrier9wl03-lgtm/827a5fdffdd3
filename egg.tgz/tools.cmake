# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(price-elasticity src/price-elasticity.cpp)
set_property(TARGET price-elasticity PROPERTY CXX_STANDARD 11)
target_link_libraries(price-elasticity lionss pthread)

add_executable(spc-xbar src/spc-xbar.cpp)
set_property(TARGET spc-xbar PROPERTY CXX_STANDARD 11)
target_link_libraries(spc-xbar lionss pthread)

add_executable(MsPacmanRl src/MsPacmanRl.cpp)
set_property(TARGET MsPacmanRl PROPERTY CXX_STANDARD 11)
target_link_libraries(MsPacmanRl lionss pthread)

add_executable(vesper src/vesper.cpp)
set_property(TARGET vesper PROPERTY CXX_STANDARD 11)
target_link_libraries(vesper lionss pthread)

add_executable(ospfArea0 src/ospfArea0.cpp)
set_property(TARGET ospfArea0 PROPERTY CXX_STANDARD 11)
target_link_libraries(ospfArea0 lionss pthread)

add_executable(isthmus src/isthmus.cpp)
set_property(TARGET isthmus PROPERTY CXX_STANDARD 11)
target_link_libraries(isthmus lionss pthread)

add_executable(cargoLoadplan src/cargoLoadplan.cpp)
set_property(TARGET cargoLoadplan PROPERTY CXX_STANDARD 11)
target_link_libraries(cargoLoadplan lionss pthread)

add_executable(jade4 src/jade4.cpp)
set_property(TARGET jade4 PROPERTY CXX_STANDARD 11)
target_link_libraries(jade4 lionss pthread)

add_executable(yarrow src/yarrow.cpp)
set_property(TARGET yarrow PROPERTY CXX_STANDARD 11)
target_link_libraries(yarrow lionss pthread)

add_executable(ct-fbp src/ct-fbp.cpp)
set_property(TARGET ct-fbp PROPERTY CXX_STANDARD 11)
target_link_libraries(ct-fbp lionss pthread)

add_executable(claims-triage src/claims-triage.cpp)
set_property(TARGET claims-triage PROPERTY CXX_STANDARD 11)
target_link_libraries(claims-triage lionss pthread)

add_executable(nickel src/nickel.cpp)
set_property(TARGET nickel PROPERTY CXX_STANDARD 11)
target_link_libraries(nickel lionss pthread)

add_executable(backup-verifier src/backup-verifier.cpp)
set_property(TARGET backup-verifier PROPERTY CXX_STANDARD 11)
target_link_libraries(backup-verifier lionss pthread)

add_executable(sorrel src/sorrel.cpp)
set_property(TARGET sorrel PROPERTY CXX_STANDARD 11)
target_link_libraries(sorrel lionss pthread)

add_executable(library_catalog src/library_catalog.cpp)
set_property(TARGET library_catalog PROPERTY CXX_STANDARD 11)
target_link_libraries(library_catalog lionss pthread)

add_executable(sagaOrders src/sagaOrders.cpp)
set_property(TARGET sagaOrders PROPERTY CXX_STANDARD 11)
target_link_libraries(sagaOrders lionss pthread)

add_executable(pathtraceCorner src/pathtraceCorner.cpp)
set_property(TARGET pathtraceCorner PROPERTY CXX_STANDARD 11)
target_link_libraries(pathtraceCorner lionss pthread)

add_executable(quizforge src/quizforge.cpp)
set_property(TARGET quizforge PROPERTY CXX_STANDARD 11)
target_link_libraries(quizforge lionss pthread)

add_executable(logchew src/logchew.cpp)
set_property(TARGET logchew PROPERTY CXX_STANDARD 11)
target_link_libraries(logchew lionss pthread)

add_executable(antennaDipole src/antennaDipole.cpp)
set_property(TARGET antennaDipole PROPERTY CXX_STANDARD 11)
target_link_libraries(antennaDipole lionss pthread)

add_executable(license-scan src/license-scan.cpp)
set_property(TARGET license-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(license-scan lionss pthread)

add_executable(mri_cs_recon src/mri_cs_recon.cpp)
set_property(TARGET mri_cs_recon PROPERTY CXX_STANDARD 11)
target_link_libraries(mri_cs_recon lionss pthread)

add_executable(FhirIntake src/FhirIntake.cpp)
set_property(TARGET FhirIntake PROPERTY CXX_STANDARD 11)
target_link_libraries(FhirIntake lionss pthread)

add_executable(shortlink src/shortlink.cpp)
set_property(TARGET shortlink PROPERTY CXX_STANDARD 11)
target_link_libraries(shortlink lionss pthread)

add_executable(nimbus2 src/nimbus2.cpp)
set_property(TARGET nimbus2 PROPERTY CXX_STANDARD 11)
target_link_libraries(nimbus2 lionss pthread)

add_executable(hemlock src/hemlock.cpp)
set_property(TARGET hemlock PROPERTY CXX_STANDARD 11)
target_link_libraries(hemlock lionss pthread)

add_executable(certexpiryscan src/certexpiryscan.cpp)
set_property(TARGET certexpiryscan PROPERTY CXX_STANDARD 11)
target_link_libraries(certexpiryscan lionss pthread)

add_executable(quill src/quill.cpp)
set_property(TARGET quill PROPERTY CXX_STANDARD 11)
target_link_libraries(quill lionss pthread)

add_executable(pageranklite src/pageranklite.cpp)
set_property(TARGET pageranklite PROPERTY CXX_STANDARD 11)
target_link_libraries(pageranklite lionss pthread)

add_executable(limestone src/limestone.cpp)
set_property(TARGET limestone PROPERTY CXX_STANDARD 11)
target_link_libraries(limestone lionss pthread)

